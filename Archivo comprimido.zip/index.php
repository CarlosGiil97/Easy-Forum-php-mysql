<?php 
  include_once 'contadorVisitas.php';
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Foro</title>

    <link rel="icon" href="./favicon.ico" type="image/x-icon">    
  </head>
  <?php include './header.php'?>
  <body>
  <div align="center" class="mt-5">
    <a type="button" class="btn btn-warning hell"  href="login.php" style="width:50%"><font size="6">Login</font>
</a>
    <a type="button" class="btn btn-success" href="crearusuario.php"aria-haspopup="true" aria-expanded="false" style="width:50%"><font size="6">Registro</font>
</a>
</div>
	
  </body>
</html>
