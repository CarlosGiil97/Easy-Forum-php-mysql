<div class="cookie-consent">

    <span>Esta web usa cookies para mejorar la experiencia del usuario.</span>
    <div class="mt-2 d-flex align-items-center justify-content-center g-2">
    <button class="allow-button mr-1" onclick="saveCookies()">Permitir</button>
    <button class="allow-button" onclick="dontSaveCookies()">Cancelar</button>
    </div>

</div> 

